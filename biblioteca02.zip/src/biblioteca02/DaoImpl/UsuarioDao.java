package biblioteca02.DaoImpl;

import biblioteca02.Dao.Dao;
import biblioteca02.Entidades.Usuario;

public interface UsuarioDao extends Dao<Usuario>{     
    
}
