package biblioteca02.DaoImpl;

import biblioteca02.Dao.DaoException;
import biblioteca02.Entidades.Usuario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import javax.persistence.TypedQuery;

public class UsuarioDaoImpl implements UsuarioDao{

    @Override
    public void save(Usuario data) throws DaoException {
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("biblioteca02PU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();  
            em.persist(data);
            em.getTransaction().commit();  
            em.close();
            emf.close();
        } 
            catch (Exception e) {
                throw new DaoException(e.getMessage());
        }
        
    }

    @Override
    public void update(Usuario data) throws DaoException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/Generat 
    }

    @Override
    public void delete(Usuario data) throws DaoException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Usuario> getAll() throws DaoException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Usuario getById(long id) throws DaoException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    


    /*
    public List<Usuario> buscarPorApellidoODni(String texto) throws DaoException {
        
        
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("biblioteca02PU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();  
            String jpql = "SELECT u FROM Usuarios u WHERE u.apellido LIKE :texto";
            TypedQuery<Usuario> query = em.createQuery(jpql, Usuario.class);
            query.setParameter("texto", "%" + texto + "%");
            return query.getResultList();
        } catch (Exception e) {
            throw new DaoException(e.getMessage());
        }
    }
    
    public List<Usuarios> buscarPorApellidoODni(String texto){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("biblioteca02PU");
        EntityManager em=emf.createEntityManager();
        try {
            return em.createQuery("select u from usuario where u.apellido like :texto", Usuario.class)
                    .setParameter("texto","%" + texto + "%").getResultList();
        } finally (em.close()) {
        }
    }*/


    
}
    
    

