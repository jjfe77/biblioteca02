package biblioteca02.JPanel;

public class Biblioteca02 {

    public static void main(String[] args) {
        new Principal().setVisible(true);
    }
    
}
